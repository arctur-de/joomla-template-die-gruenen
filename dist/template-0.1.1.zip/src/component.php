<?php
/** 
 *------------------------------------------------------------------------------
 * @copyright     Copyright (C) 2016-2020 arctur.de. All Rights Reserved.
 * @authors       Arctur Internet Consulting GbR
 * @Link:         http://www.arctur.de 
 *------------------------------------------------------------------------------
 */


// no direct access
defined ( '_JEXEC' ) or die ( 'Restricted access' );

include(dirname(__FILE__) . '/index.php');

T3::getApp()->addCss('windows');