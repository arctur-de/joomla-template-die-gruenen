/** 
 *------------------------------------------------------------------------------
 * @copyright     Copyright (C) 2016-2020 arctur.de. All Rights Reserved.
 * @authors       Arctur Internet Consulting GbR
 * @Link:         http://www.arctur.de 
 *------------------------------------------------------------------------------
 */